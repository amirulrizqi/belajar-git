fun main() {
    val name = "Amirul"

    print("Hello my name is ")
         println(name)
         print(if (true) "Hobi saya bermotor" else "hobi saya motor")
}

